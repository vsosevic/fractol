/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fractal.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spovod <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/22 18:06:13 by spovod            #+#    #+#             */
/*   Updated: 2017/03/01 18:32:16 by spovod           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FRACTAL_H
# define FRACTAL_H
# include "mlx.h"
# include <math.h>
# include <stdlib.h>
# define HI 1000
# define WI 1000
# define MOTION_NOTIFY 6
# define PTR_MOTION_MASK 1L<<6

typedef struct	s_cmplx
{
	double re;
	double im;
}				t_cmplx;

typedef struct	s_ftl
{
	t_cmplx	z;
	t_cmplx	c;
	int		prec;
	int		max_prec;
	double	zoom;
	int		init_x;
	int		init_y;
	double	free_x;
	double	free_y;
	int		stop;
}				t_ftl;

typedef struct	s_window
{
	void	*mlx;
	void	*win;
	void	*imag;
}				t_window;

typedef struct	s_general
{
	t_window	w;
	char		*color;
	t_ftl		*f;
	int			bpp;
	int			size_line;
	int			endian;
}				t_general;

void			fractol_mondel(char *color, int size_line, t_ftl *f);
void			julia(char *color, int size_line, t_ftl *f);
void			juli_main(void);
void			mondel_main(void);
int				ft_strcmp(const char *s1, const char *s2);
void			serp_main(void);
void			ft_init_ftl(t_general **g);
void			burn_ship_main(void);
void			burn_ship(char *color, int size_line, t_ftl *f);

#endif
