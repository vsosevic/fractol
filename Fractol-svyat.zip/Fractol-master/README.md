# Fractol

This project is meant to create graphically fractals.

To build the project requires installation interface library MiniLibX (assembly instractions for MacOS you can see in Makefile).

Use mouse whell for zoom all of types fractals; arrows - for correspond movement;
move the mouse to change Julia's fractal.
