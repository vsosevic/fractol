/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spovod <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/21 20:05:30 by spovod            #+#    #+#             */
/*   Updated: 2017/03/01 18:47:45 by spovod           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractal.h"
#include <unistd.h>

int	main(int ac, char **av)
{
	if (ac != 2)
	{
		write(1, "Julia = j Mondelbrot = m Burn_ship = b Serpinsky = s\n", 53);
		return (0);
	}
	if (ft_strcmp("j", av[1]) == 0)
		juli_main();
	else if (ft_strcmp("m", av[1]) == 0)
		mondel_main();
	else if (ft_strcmp("s", av[1]) == 0)
		serp_main();
	else if (ft_strcmp("b", av[1]) == 0)
		burn_ship_main();
	else
		write(1, "Julia = j Mondelbrot = m Burn_ship = b Serpinsky = s\n", 53);
	return (0);
}
