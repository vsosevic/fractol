/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spovod <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/28 19:57:28 by spovod            #+#    #+#             */
/*   Updated: 2017/02/28 21:23:13 by spovod           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractal.h"

void	ft_init_ftl(t_general **g)
{
	(*g) = (t_general *)malloc(sizeof(t_general));
	(*g)->f = (t_ftl *)malloc(sizeof(t_ftl));
	(*g)->f->z.re = 0;
	(*g)->f->z.im = 0;
	(*g)->f->zoom = 300;
	(*g)->f->init_x = 500;
	(*g)->f->init_y = 500;
	(*g)->f->free_x = -0.8;
	(*g)->f->free_y = 0;
	(*g)->f->stop = 0;
	(*g)->f->prec = 30;
}
