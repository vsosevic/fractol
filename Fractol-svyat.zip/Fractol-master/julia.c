/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   julia.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spovod <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/28 15:48:30 by spovod            #+#    #+#             */
/*   Updated: 2017/02/28 21:34:41 by spovod           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractal.h"

static void	parse_julia(char *color, int c, t_ftl *f, int i)
{
	int		k;
	double	h;

	k = 0;
	while (k < f->prec)
	{
		h = f->z.re;
		f->z.re = f->z.re * f->z.re - f->z.im * f->z.im + f->free_x;
		f->z.im = 2 * h * f->z.im + f->free_y;
		k++;
		if (f->z.re * f->z.re + f->z.im * f->z.im > 4)
			break ;
	}
	if (k < f->prec)
	{
		color[c] = 0;
		color[++c] = (100 + i * k) >> 5;
		color[++c] = (100 + i * k) >> 3;
	}
	else
	{
		color[++c] = 100;
		color[++c] = (i) >> 8;
	}
}

void		julia(char *color, int size_line, t_ftl *f)
{
	int p;
	int q;
	int c;
	int	i;

	i = (0x00FFFFFF - 0x00000000) / 1000;
	p = 0;
	while (p < HI)
	{
		q = 0;
		while (q < WI)
		{
			f->z.re = ((double)(p) - f->init_x) / f->zoom;
			f->z.im = ((double)q - f->init_y) / f->zoom;
			c = (p) * 4 + (q) * size_line;
			parse_julia(color, c, f, i);
			q += 1;
		}
		p += 1;
	}
}
