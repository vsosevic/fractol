/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mondel_main.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spovod <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/27 19:23:39 by spovod            #+#    #+#             */
/*   Updated: 2017/02/28 21:28:43 by spovod           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractal.h"

static int	expose_hook_mon(t_general *g)
{
	g->w.imag = mlx_new_image(g->w.mlx, HI, WI);
	g->color = mlx_get_data_addr(g->w.imag, &(g->bpp),
			&(g->size_line), &(g->endian));
	burn_ship(g->color, g->size_line, g->f);
	mlx_put_image_to_window(g->w.mlx, g->w.win, g->w.imag, 0, 0);
	mlx_destroy_image(g->w.mlx, g->w.imag);
	return (0);
}

static int	my_key_funct(int keycode, t_general *g)
{
	if (keycode == 53)
		exit(1);
	if (keycode == 126)
		g->f->init_y -= 10;
	if (keycode == 125)
		g->f->init_y += 10;
	if (keycode == 123)
		g->f->init_x -= 10;
	if (keycode == 124)
		g->f->init_x += 10;
	if (keycode == 78)
		g->f->prec -= (g->f->prec <= 3) ? 0 : 3;
	if (keycode == 69)
		g->f->prec += (g->f->prec >= 200) ? 0 : 3;
	expose_hook_mon(g);
	return (0);
}

static int	my_mouse_funct(int mouse, int x, int y, t_general *g)
{
	if (mouse == 4)
	{
		g->f->zoom *= 1.1;
		g->f->init_x -= 0.1 * (x - g->f->init_x);
		g->f->init_y -= 0.1 * (y - g->f->init_y);
		expose_hook_mon(g);
	}
	if (mouse == 5)
	{
		g->f->init_x += 0.1 * (x - g->f->init_x);
		g->f->init_y += 0.1 * (y - g->f->init_y);
		g->f->zoom *= 0.9;
		expose_hook_mon(g);
	}
	return (0);
}

void		burn_ship_main(void)
{
	t_general *g;

	ft_init_ftl(&g);
	g->w.mlx = mlx_init();
	g->w.win = mlx_new_window(g->w.mlx, HI, WI, "mlx 42");
	mlx_expose_hook(g->w.win, expose_hook_mon, g);
	mlx_mouse_hook(g->w.win, my_mouse_funct, g);
	mlx_key_hook(g->w.win, my_key_funct, g);
	mlx_loop(g->w.mlx);
}
