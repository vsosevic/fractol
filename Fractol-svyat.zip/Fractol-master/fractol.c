/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fractol.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spovod <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/28 17:26:06 by spovod            #+#    #+#             */
/*   Updated: 2017/02/28 21:33:56 by spovod           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractal.h"

static void	parse_mondel(char *color, int c, int k, int prec)
{
	int i;

	i = (0x00FFFFFF - 0x00000000) / 1000;
	if (k < prec)
	{
		color[c] = 100;
		color[++c] = (100 + i * k) >> 5;
	}
	else
		color[c] = 0;
}

static int	iter_mondel(int p, int q, t_ftl *f)
{
	double h;

	h = f->z.re;
	f->z.re = f->z.re * f->z.re - f->z.im * f->z.im + ((double)(p)
			- f->init_x) / f->zoom;
	f->z.im = 2 * h * f->z.im + ((double)q - f->init_y) / f->zoom;
	return (1);
}

void		fractol_mondel(char *color, int size_line, t_ftl *f)
{
	int k;
	int p;
	int q;
	int c;

	p = 0;
	while (p < 1000)
	{
		q = 0;
		while (q < 1000)
		{
			f->z.re = 0;
			f->z.im = 0;
			k = 0;
			while (k < f->prec && f->z.re * f->z.re + f->z.im * f->z.im < 4)
				k += iter_mondel(p, q, f);
			c = (p) * 4 + (q) * size_line;
			parse_mondel(color, c, k, f->prec);
			q += 1;
		}
		p += 1;
	}
}
