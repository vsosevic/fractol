/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   serpinsky.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spovod <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/27 20:48:11 by spovod            #+#    #+#             */
/*   Updated: 2017/03/01 18:45:54 by spovod           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractal.h"

static void	serp2(t_general *g)
{
	int i;
	int j;
	int x;
	int y;

	i = 0;
	while (i < 1000)
	{
		j = 0;
		while (j < 1000)
		{
			x = (i + g->f->init_x) * g->f->zoom;
			y = (j + g->f->init_y) * g->f->zoom;
			while (x > 0 && y > 0)
			{
				if (x % 3 == 1 && y % 3 == 1)
					g->color[4 * (i) + g->size_line * (j)] = 100;
				x /= 3;
				y /= 3;
			}
			j++;
		}
		i++;
	}
}

static int	expose_hook(t_general *g)
{
	g->w.imag = mlx_new_image(g->w.mlx, HI, WI);
	g->color = mlx_get_data_addr(g->w.imag, &(g->bpp),
			&(g->size_line), &(g->endian));
	serp2(g);
	mlx_put_image_to_window(g->w.mlx, g->w.win, g->w.imag, 0, 0);
	mlx_destroy_image(g->w.mlx, g->w.imag);
	return (0);
}

static int	my_key_funct(int keycode, t_general *g)
{
	if (keycode == 53)
		exit(1);
	if (keycode == 69)
		(g)->f->zoom *= 1.01;
	if (keycode == 78)
		(g)->f->zoom *= 0.99;
	if (keycode == 123)
		(g)->f->init_x += 10;
	if (keycode == 124)
		(g)->f->init_x -= 10;
	if (keycode == 126)
		(g)->f->init_y += 10;
	if (keycode == 125)
		(g)->f->init_y -= 10;
	expose_hook(g);
	return (0);
}

void		serp_main(void)
{
	t_general *g;

	ft_init_ftl(&g);
	g->f->zoom = 0.1;
	g->f->init_y = 0;
	g->f->init_x = 0;
	g->w.mlx = mlx_init();
	g->w.win = mlx_new_window(g->w.mlx, HI, WI, "mlx 42");
	mlx_expose_hook(g->w.win, expose_hook, g);
	mlx_key_hook(g->w.win, my_key_funct, g);
	mlx_loop(g->w.mlx);
}
